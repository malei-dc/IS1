#CoreUpdates folder
This directory holds Cuis updates (ChangeSets).
Those numbered above the image name suffix can be installed to update it.