# SVG
Support for SVG (Scalable Vector Graphics) files
